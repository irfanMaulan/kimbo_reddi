@extends('page.template.master')
@section('content')
<br>
<div class="card">
    <div class="card-header">
        <h3 class="card-title">Kode Uniq</h3>
        <div class="card-tools">

        </div>
    </div>
    <div class="card-body">
        <form action="{{ url('/kode-unik') }}" method="get">
            @csrf
            <div class="row">
                <div class="col-md-3">
                    <select class="form-control" name="reward_type_detail_id" aria-label="Default select example">
                        <option value="" selected>Hadiah</option>
                        <option value="1" {{ request()->get('reward_type_detail_id') == 1 ? "selected":"" }}>Umroh</option>
                        <option value="2" {{ request()->get('reward_type_detail_id') == 2 ? "selected":"" }}>Pulsa</option>
                        <option value="3" {{ request()->get('reward_type_detail_id') == 3 ? "selected":"" }}>Belum Beruntung</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <select class="form-control" name="status" aria-label="Default select example">
                        <option value="" selected>Status</option>
                        <option value="used" {{ request()->get('status') == 'used' ? "selected":"" }}>Terpakai</option>
                        <option value="available" {{ request()->get('status') == 'available' ? "selected":"" }}>Tersedia</option>
                    </select>
                </div>
                <div class="col-md-3">
                    <input type="text" name="code" class="form-control" id="" placeholder="Search" value="{{ !empty(request()->get('code')) ? request()->get('code'): "" }}">
                </div>
                <div class="col-md-3">
                    <button type="submit" id="btn_search" class="btn btn-primary">Search</button>
                </div>
            </div>
            <br>
            <div class="col-md-10"></div>
        </form>
        <!-- <form action="{{ url('/kode-unik') }}" method="get">
            @csrf
            <div class="row">
                <div class="col-md-3">
                    <select class="form-control" name="page" id="total_page" aria-label="Default select example" style="width: 25%;">
                        <option value="20" selected>20</option>
                        <option value="40">40</option>
                        <option value="60">60</option>
                        <option value="80">80</option>
                        <option value="100">100</option>
                    </select>
                </div>
                <div class="col-md-3"></div>
                <div class="col-md-3"></div>
                <div class="col-md-3 text-end">
                    <div class="search-container">
                        <div class="row">
                            <div class="col-md-2"><button type="submit" class="btn btn-primary"><i class="fa fa-search"></i></button></div>
                        </div>
                    </div>
                </div>
            </div>
        </form> -->
    </div>

    <div class="col-md-12">
        <table class="table tablr-striped table-bordered" id="example">
            <thead>
                <th>No</th>
                <th>Kode Unik</th>
                <th>Hadiah</th>
                <th>Status</th>
                <th>Aksi</th>
            </thead>
            <tbody>
                @foreach($response as $res)
                    <tr>
                        <td>{{ $no++ }}</td>
                        <td>{{ $res->code ? $res->code : '' }}</td>
                        <td>{{ $res->reward ? $res->reward : '' }}</td>
                        <td>{{ $res->status ? $res->status : '' }}</td>
                        <!-- <td><button type="button" class="btn btn-success" id="btn_update" data-toggle="modal" data-json="{{json_encode($res)}}" data-target=".bd-example-modal-lg"><i class="fas fa-edit"></i> &nbsp; Edit</button></td> -->
                        <td>
                            <button type="button" class="btn show-modal-data" data-json='{{ json_encode($res) }}' data-toggle="modal" data-target="#exampleModalCenter">
                                <i class="fa fa-trash" style="color:#DC3C4D"></i>
                            </button>
                        </td>
                    </tr>
                @endforeach
            </tbody>
        </table>

    </div>
</div>

<div class="modal fade" id="exampleModalCenter" tabindex="-1" role="dialog" aria-labelledby="exampleModalCenterTitle" aria-hidden="true">
    <form action="{{ url('kode-unik/update') }}" method="post">
        @csrf
        <div class="modal-dialog modal-dialog-centered" role="document">
            <div class="modal-content">
                <div class="modal-body">
                    <div class="row">
                        <div class="col-md-3">Kode Uniq</div>
                        <div class="col-md-9"><input type="text" class="form-control" id="kode_uniq" name="kode_uniq" value="" disabled></div>
                        <input type="hidden" name="id_uniq" id="id_uniq">
                    </div><br>

                    <div class="row">
                        <div class="col-md-3">Hadiah</div>
                        <div class="col-md-9">
                            <select class="form-control" name="reward_type_detail_id" aria-label="Default select example">
                                <option selected>Hadiah</option>
                                <option value="1">Umroh</option>
                                <option value="2">Pulsa</option>
                                <option value="3">Belum Beruntung</option>
                            </select>
                        </div>
                    </div><br>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Save changes</button>
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                </div>
            </div>
        </div>
    </form>
</div>
@endsection

@section('script')
<link rel="stylesheet" href="https://cdn.datatables.net/1.13.5/css/jquery.dataTables.min.css">
<script src="https://code.jquery.com/jquery-3.7.0.js"></script>
<script src="https://cdn.datatables.net/1.13.5/js/jquery.dataTables.min.js"></script>
<script>

    // $(document).ready(function() {
    //     var table = $('#example').DataTable({
    //         "ordering": false,
    //         "processing": true,
    //     });

    // })

    $("#forn_search").keyup(function () {
        code = $(this).val();
        $.ajax({
            url: "{{url('/kode-unik')}}",
            type: "GET",
            data: {
                "_token": "{{ csrf_token() }}",
                "code": code,
            },
            cache: false,
            success: function(data) {
                console.log(data)
            },
        });
    });

    $('.show-modal-data').change(function() {
        var datas = JSON.parse($(this).attr('data-json'))
        console.log('datas =', datas)

        $('[name="kode_uniq"]').val(datas.code);
        $('[name="id_uniq"]').val(datas.id);
        $('[name="reward_type_detail_id"]').val(datas.reward_type_detail_id).change()
        // $('#code_prod').html(row.product_code)
        // document.getElementById('code_prod').innerText = datas.product_code;
        // document.getElementById('prod_name').innerText = datas.product_name;


    })
</script>
@endsection
